using System;class WaveVR_COMMITINFO{public static string wavevr_version = @"
commit bdceac5bc6264dacb9d00fac82e64f3f81c053c1
";}
